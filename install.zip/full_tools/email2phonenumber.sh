#!/bin/bash
#
# Created by: Informatic_in_Termux
#
# VARIABLES
#
PWD=$(pwd)
source ${PWD}/Colors.sh
#
# CÓDIGO
#
if [ -x ${HOME}/email2phonenumber ]
then
cd ${HOME}/SysO-Termux/full_tools
else
cd
clear
echo -e "${verde}
┌═════════════════════════════════┐
█ ${blanco}Instalando email2phonenumber... ${verde}█
└═════════════════════════════════┘
"${blanco}
pkg install -y python
pip install --upgrade pip
git clone https://github.com/martinvigo/email2phonenumber
cd email2phonenumber
python -m pip install -r requirements.txt
cd
cd ${HOME}/SysO-Termux/full_tools
fi
