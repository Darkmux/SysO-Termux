#!/bin/bash
#
# Created by: Informatic_in_Termux
#
# VARIABLES
#
PWD=$(pwd)
source ${PWD}/Colors.sh
#
# CÓDIGO
#
if [ -x ${PREFIX}/bin/ngrok ]
then
cd ${HOME}/SysO-Termux/full_tools
else
cd
clear
echo -e "${verde}
┌═════════════════════┐
█ ${blanco}Instalando ngrok... ${verde}█
└═════════════════════┘
"${blanco}
cd ${HOME}/SysO-Termux/requirements_tools
chmod 777 ngrok-stable-linux-arm.zip
unzip ngrok-stable-linux-arm.zip
cp ngrok ${PREFIX}/bin
echo -e -n "${verde}
┌════════════════════════════┐
█ ${blanco}INGRESE SU AUTHTOKEN NGROK ${verde}█
└════════════════════════════┘
┃
└═>>> "${blanco}
read -r authtoken_ngrok
${authtoken_ngrok}
rm ngrok
cd
cd ${HOME}/SysO-Termux/full_tools
fi
