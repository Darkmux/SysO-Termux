#!/bin/bash
#
# Created by: Informatic_in_Termux
#
# VARIABLES
#
PWD=$(pwd)
source ${PWD}/Colors.sh
#
# CÓDIGO
#
if [ -x ${HOME}/install.sh ]
then
cd ${HOME}/SysO-Termux/full_tools
else
cd
clear
echo -e "${verde}
┌═══════════════════════════┐
█ ${blanco}Instalando TermuxBlack... ${verde}█
└═══════════════════════════┘
"${blanco}
pkg install -y wget
wget https://raw.githubusercontent.com/Hax4us/TermuxBlack/master/install.sh
chmod 777 install.sh
sh install.sh
rm -rf .termux && cd && cd ../usr/etc && rm bash.bashrc && mv bash.bashrc.bk bash.bashrc && cd
mkdir -p $HOME/.termux/&&echo "extra-keys = [['ESC','/','-','HOME','UP','END','PGUP'],['TAB','CTRL','ALT','LEFT','DOWN','RIGHT','PGDN']]" > $HOME/.termux/termux.properties&&echo "$rst"
cd ${HOME}/SysO-Termux/full_tools
fi
