#!/bin/bash
#
# Created by: Informatic_in_Termux
#
# VARIABLES
#
PWD=$(pwd)
source ${PWD}/Colors.sh
source ${HOME}/SysO-Termux/config/already
#
# CÓDIGO
#
cd
if [ -x ${HOME}/install.sh ]
then
EXISTE
sleep 1
cd ${HOME}/SysO-Termux
source ${HOME}/SysO-Termux/SysO-Tool.sh
else
echo -e "${verde}
┌═══════════════════════════┐
█ ${blanco}Instalando TermuxBlack... ${verde}█
└═══════════════════════════┘
"${blanco}
pkg install -y wget
wget https://raw.githubusercontent.com/Hax4us/TermuxBlack/master/install.sh
chmod 777 install.sh
sh install.sh
rm -rf .termux && cd && cd ../usr/etc && rm bash.bashrc && mv bash.bashrc.bk bash.bashrc && cd
mkdir -p $HOME/.termux/&&echo "extra-keys = [['ESC','/','-','HOME','UP','END','PGUP'],['TAB','CTRL','ALT','LEFT','DOWN','RIGHT','PGDN']]" > $HOME/.termux/termux.properties&&echo "$rst"
cd ${HOME}/SysO-Termux
source ${HOME}/SysO-Termux/SysO-Tool.sh
fi
