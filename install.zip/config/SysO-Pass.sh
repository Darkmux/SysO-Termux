#!/bin/bash
#
# Created by: Informatic_in_Termux
#
# SysO-Pass
#
# VARIABLES
#
PWD=$(pwd)
verde='\033[32m'
rojo='\033[31m'
blanco='\033[37m'
#
# CÓDIGO
#
cd
echo -e -n "${verde}
┌═══════════════┐
█ ${blanco}NUEVO USUARIO ${verde}█
└═══════════════┘
┃
└═>>> "${blanco}
read -r NewUser
sleep 0.5
echo -e -n "${verde}
┌══════════════════┐
█ ${blanco}NUEVA CONTRASEÑA ${verde}█
└══════════════════┘
┃
└═>>> "${blanco}
read -r NewPass
sleep 0.5
cd && cd ../usr/etc && rm bash.bashrc && cd
cd ${HOME}/SysO-Termux/config
cp bash.bashrc ${PREFIX}/etc
echo -e "usuario=${NewUser}" >> ${PREFIX}/etc/bash.bashrc
echo -e "clave=${NewPass}" >> ${PREFIX}/etc/bash.bashrc
echo -e "source ${HOME}/SysO-Termux/config/Colors.sh" >> ${PREFIX}/etc/bash.bashrc
echo -e "source ${HOME}/SysO-Termux/config/Termux" >> ${PREFIX}/etc/bash.bashrc
echo -e "source ${HOME}/SysO-Termux/config/Login" >> ${PREFIX}/etc/bash.bashrc
echo -e "fish" >> ${PREFIX}/etc/bash.bashrc
echo -e "alias salir='exit;exit'" >> ${PREFIX}/etc/bash.bashrc
echo -e "salir" >> ${PREFIX}/etc/bash.bashrc
echo -e "${verde}
┌════════════════════════┐
█ ${blanco}CREDENCIALES CAMBIADAS ${verde}█
└════════════════════════┘
"${blanco}
