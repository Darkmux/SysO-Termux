#!/bin/bash
#
# Created by: Informatic_in_Termux
#
# SysO-Help
#
# VARIABLES
#
PWD=$(pwd)
verde='\033[32m'
blanco='\033[37m'
rojo='\033[31m'
#
# CÓDIGO
#
clear
echo -e "${verde}
┌═══════════┐
█ ${blanco}SysO-Help ${verde}█
└═══════════┘
┃    ┌═════════════════════════════════════════┐
└═>>>█ ${blanco}Imprime el Menú de Ayuda de SysO-Termux ${verde}█
     └═════════════════════════════════════════┘

┌═════════════┐
█ ${blanco}SysO-Update ${verde}█
└═════════════┘
┃    ┌═══════════════════════════════════┐
└═>>>█ ${blanco}Reinstala y Actualiza SysO-Termux ${verde}█
     └═══════════════════════════════════┘

┌══════════┐
█ ${blanco}SysO-Bot ${verde}█
└══════════┘
┃    ┌══════════════════════════════════════════┐
└═>>>█ ${blanco}Redirecciona al BOT Informatic in Termux ${verde}█
     └══════════════════════════════════════════┘

┌═══════════┐
█ ${blanco}SysO-Lock ${verde}█
└═══════════┘
┃    ┌═════════════════════════════════════════┐
└═>>>█ ${blanco}Bloquea Termux con el Login SysO-Termux ${verde}█
     └═════════════════════════════════════════┘

┌═══════════┐
█ ${blanco}SysO-Pass ${verde}█
└═══════════┘
┃    ┌════════════════════════════════════════┐
└═>>>█ ${blanco}Cambia los Datos del Login SysO-Termux ${verde}█
     └════════════════════════════════════════┘

┌═══════════┐
█ ${blanco}SysO-Sudo ${verde}█
└═══════════┘
┃    ┌══════════════════════════════════════════┐
└═>>>█ ${blanco}Cambia el Usuario Normal a Super Usuario ${verde}█
     └══════════════════════════════════════════┘

┌═══════════┐
█ ${blanco}SysO-Root ${verde}█
└═══════════┘
┃    ┌═════════════════════════════════════════════┐
└═>>>█ ${blanco}Falsifica y Cambia el Usuario Normal a Root ${verde}█
     └═════════════════════════════════════════════┘

┌═══════════┐
█ ${blanco}SysO-BeEF ${verde}█
└═══════════┘
┃    ┌════════════════════════════════════════════┐
└═>>>█ ${blanco}Ejecuta BeEF, Reiniciando la Base de Datos ${verde}█
     └════════════════════════════════════════════┘

┌═══════════┐
█ ${blanco}SysO-GoPh ${verde}█
└═══════════┘
┃    ┌══════════════════════════════════════┐
└═>>>█ ${blanco}Ejecuta GoPhish de Manera Automática ${verde}█
     └══════════════════════════════════════┘

┌══════════┐
█ ${blanco}SysO-Msf ${verde}█
└══════════┘
┃    ┌════════════════════════════════════════════┐
└═>>>█ ${blanco}Ejecuta la Consola de Metasploit-Framework ${verde}█
     └════════════════════════════════════════════┘

┌══════════┐
█ ${blanco}SysO-Rsf ${verde}█
└══════════┘
┃    ┌═══════════════════════════════════════════┐
└═>>>█ ${blanco}Ejecuta RouterSploit de Manera Automática ${verde}█
     └═══════════════════════════════════════════┘

┌═════════┐
█ ${blanco}SysO-IP ${verde}█
└═════════┘
┃    ┌═════════════════════════════════════════┐
└═>>>█ ${blanco}Imprime la IP del Proveedor de Internet ${verde}█
     └═════════════════════════════════════════┘
"${blanco}
